#!/bin/bash
OUTPUT_DIR="/root/Rutuja"
mkdir -p "$OUTPUT_DIR"
find . -type f -name "*.yaml" -exec cp {} "$OUTPUT_DIR" \;